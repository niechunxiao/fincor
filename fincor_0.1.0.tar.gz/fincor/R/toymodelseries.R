#' This function generates n time series within a cluster from one factor.
#'
#' @param f Factor
#' @param n n time series
#' @param u The vector u is used to generate the coefficients.
#' @param s The symbol s controls the random perturbation term of the cluster.
#'
#' @return A matrix containing n time series.
#' @export
#'
#' @examples
toymodelseries<-function(f,n,u,s){
  #This function generates n time series within a cluster from one factor.
  nf=length(f)
  sf=matrix(data=0,nrow = nf,ncol = n)

  for (i in 1:n){
    sf[,i]=runif(1, min =u[1], max = u[2])*f+ rnorm(nf,mean=0,sd=s)
  }
  return(sf)
}
