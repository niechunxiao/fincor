#' This function calculates the distance between two correlation matrices.
#'
#' @param M1 The first matrix.
#' @param M2 The second matrix.
#'
#' @return Frobenius distance between matrices.
#' @export
#'
#' @examples
matfrodist<-function(M1,M2){
  d12=(sum((M1-M2)^2))^(1/2)
  return(d12)
}
