#' This function generates a correlation matrix sequence.
#'
#' @param r return time series.
#' @param Lw The symbol Lw indicates the length of the calculation window.
#'
#' @return A correlation matrix sequence and its distance matrix.
#' @export
#'
#' @examples sq=corrmatseq(r,100)
corrmatseq<-function(r,Lw){
  #This function is used to calculate the correlation matrix sequence and calculate the distance matrix between the matrices.
  n=dim(r)
  m=n[1]-Lw+1
  cm=array(0, dim = c(n[2],n[2],m))
  for (i in 1:m){
    cm[,,i]=cor(r[i:c(i+Lw-1),])
  }
  d1=matrix(data = 0,nrow = m,ncol = m)
  for (i in 1:m){
    for (j in 1:m){
      if (i>j){
        d1[i,j]=matfrodist(cm[,,i],cm[,,j])
      }
    }
  }
  d=d1+t(d1)
  output=list(cm=cm,d=d)
  return(output)
}
