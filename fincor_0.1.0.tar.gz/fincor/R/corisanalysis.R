#' This function implements IS-analysis.
#'
#' @param r Return time series
#' @param Lw Lw represents the length of the calculation window.
#' @param k The k represents the parameter of the kNN network.
#'
#' @return A list of the main results of the IS-based analysis.
#' @export
#'
#' @examples IS=corisanalysis(r,100,20)
corisanalysis<-function(r,Lw,k){
  #This function implements IS-analysis.
  cors=corrmatseq(r,Lw)
  d=cors$d
  cm=cors$cm
  tk=dtoknnnetwork(d,k)
  dw=d*tk
  n=dim(dw)
  degtk=colSums(tk)
  IS=matrix(data=0,nrow = n[1],ncol=1)
  for (i in 1:n[1]){
    IS[i]=sum(dw[i,])/degtk[i]
  }
  output=list(IS=IS,d=d,cm=cm)
  return(output)
}
