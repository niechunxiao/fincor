#' This function calculates the distance matrix for a set of assets.
#'
#' @param r The symbol r denotes the return series, where each column corresponds to an asset.
#'
#' @return A distance matrix.
#' @export
#'
#' @examples d=findistance(r)
findistance<-function(r){
  #This function is used to calculate a matrix of distances between a group of stocks or assets, where the input is the matrix and each column is a series of returns for an asset.
  n=dim(r)
  d=matrix(data=1,nrow=n[2],ncol = n[2])-cor(r)
  return(d)
}
