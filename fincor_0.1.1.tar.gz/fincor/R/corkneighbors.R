#' A function to find neighbors (correlation matrix).
#'
#' @param cm Correlation matrix
#' @param i The label of the node.
#' @param k k neighbors.
#'
#' @return A collection of k neighbors.
#' @export
#'
#' @examples
corkneighbors<-function(cm,i,k){
  #This function detects the k neighbors of node i.
  cmi=cm[i,]
  s1=unique(cmi)
  s2=sort(s1,decreasing = TRUE)
  k1=k+1
  sk=s2[k1]
  ci=ifelse(cmi>=sk,1,0)
  return(ci)
}
