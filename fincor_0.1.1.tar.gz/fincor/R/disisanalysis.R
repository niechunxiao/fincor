#' This function performs IS analysis through a distance matrix.
#'
#' @param d Distance matrix
#' @param k The k represents the parameter of the kNN network.
#'
#' @return A list of the main results of the IS-based analysis.
#' @export
#'
#' @examples IS=corisanalysis(d,20)
disisanalysis<-function(d,k){
  #This function implements IS-analysis.
  tk=dtoknnnetwork(d,k)
  dw=d*tk
  n=dim(dw)
  degtk=colSums(tk)
  IS=matrix(data=0,nrow = n[1],ncol=1)
  for (i in 1:n[1]){
    IS[i]=sum(dw[i,])/degtk[i]
  }
  output=list(IS=IS,tk=tk,dw=dw)
  return(output)
}
