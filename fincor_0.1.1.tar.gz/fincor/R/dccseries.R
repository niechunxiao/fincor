#' A function that calculates a series of correlation coefficients.
#'
#' @param r1 series 1
#' @param r2 series 2
#' @param pm AR parameter of the ARMA model.
#' @param qm MA parameter of the ARMA model.
#' @param pg Parameter of the GARCH(pg,qg) model (ARCH).
#' @param qg Parameter of the GARCH(pg,qg) model (GARCH).
#' @param dis The parameter of the distribution, which can be set to "mvt" or "norm".
#'
#' @return A series of correlation coefficients.
#' @export
#'
#' @examples dccs=dccseries(r1,r2,1,1,1,1,"mvt")
dccseries<-function(r1,r2,pm,qm,pg,qg,dis){
  spec1 = ugarchspec(variance.model = list(model="sGARCH",garchOrder=c(pg,qg)),mean.model = list(armaOrder=c(pm,qm)),distribution.model  = "std")
  spec2 = ugarchspec(variance.model = list(model="sGARCH",garchOrder=c(pg,qg)),mean.model = list(armaOrder=c(pm,qm)),distribution.model  = "std")
  mspec = multispec( c( spec1, spec2 ) )
  spec = dccspec(mspec, VAR = FALSE, robust = FALSE,external.regressors = NULL,dccOrder = c(1,1), model = "DCC", distribution = dis)
  r=cbind(r1,r2)
  m=dccfit(spec,r[,c(1,2)], out.sample = 0, solver = "solnp", solver.control = list(), fit.control = list(eval.se = TRUE, stationarity = TRUE, scale = FALSE),cluster = NULL, fit = NULL, VAR.fit = NULL, realizedVol = NULL)
  rcorm=rcor(m)
  cs = rcorm[1,2,]
  return(cs)
}
