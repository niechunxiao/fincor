#' A function used to calculate a matrix sequence of DCC-based correlation coefficients.
#'
#' @param r Each column and row of time series data corresponds to a variable and a timestamp, respectively.
#' @param pm AR parameter of the ARMA model.
#' @param qm MA parameter of the ARMA model.
#' @param pg Parameter of the GARCH(pg,qg) model (ARCH).
#' @param qg Parameter of the GARCH(pg,qg) model (GARCH).
#' @param dis The parameter of the distribution, which can be set to "mvt" or "norm".
#'
#' @return The matrix sequence is represented by a three-dimensional array, with a third dimension corresponding to time.
#' @export
#'
#' @examples dccm=dccmatrix(r,1,1,1,1,"mvt")
dccmatrix<-function(r,pm,qm,pg,qg,dis){
  n=dim(r)
  dccm=array(0,dim=c(n[2],n[2],n[1]))
  for(i in 1:n[2]){
    for(j in 1:n[2]){
      if(j>i){
        dccm[i,j,]=dccseries(r[,i],r[,j],pm,qm,pg,qg,dis)
      }
    }
  }
  for(i in 1:n[2]){
    for(j in 1:n[2]){
      if(j<i){
        dccm[i,j,]=dccm[j,i,]
      }
    }
  }
  for(i in 1:n[2]){
    dccm[i,i,]=array(1,dim=c(1,n[1]))
  }
  return(dccm)
}
