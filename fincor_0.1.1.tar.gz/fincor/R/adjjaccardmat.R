#' This function calculates the Jaccard similarity matrix between nodes.
#'
#' @param t Adjacency matrix.
#'
#' @return Jaccard similarity matrix
#' @export
#'
#' @examples J=adjjaccardmat(adj)
adjjaccardmat<-function(t){
  library(igraph)
  t1=graph_from_adjacency_matrix(t,mode="undirected",weighted = NULL,diag=FALSE)
  J=similarity(t1,mode = "all",loops = FALSE,method = "jaccard")
  return(J)
}
