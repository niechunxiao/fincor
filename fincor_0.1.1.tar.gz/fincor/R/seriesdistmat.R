#' A function that calculates a distance matrix for a set of time series.
#'
#' @param r Each column and row of time series data corresponds to a variable and a timestamp, respectively.
#'
#' @return Distance matrix
#' @export
#'
#' @examples d=seriesdistmat(r)
seriesdistmat<-function(r){
  corr=cor(r)
  n=dim(r)
  d01=matrix(data=1,n[2],n[2])
  d=(2*(d01-corr))^(1/2)
  return(d)
}
