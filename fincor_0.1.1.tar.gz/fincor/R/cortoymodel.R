#' This function generates a family of time series with a cluster structure.
#'
#' @param cf The symbol cf represents the correlation coefficient matrix between factors.
#' @param n Each component of vector n is the number of time series in a cluster.
#' @param u The matrix u is used to generate the coefficients.
#' @param s The vector s controls the random perturbation term of the clusters.
#' @param L The symbol L represents the length of the time series.
#'
#' @return A family of time series with a cluster structure.
#' @export
#'
#' @examples x=c(1.0,0.65,0.66,0.61,0.65,1.0,0.82,0.75,0.66,0.82,1.0,0.78,0.61,0.75,0.78,1.0)
#' @examples cf=matrix(data=x,nrow = 4,ncol = 4,byrow = TRUE)
#' @examples n=c(15,10,10,15)
#' @examples u=matrix(data=c(0.6,0.7,0.5,0.7,0.8,0.9,0.7,0.8),nrow=4,ncol=2,byrow=TRUE)
#' @examples s=c(0.3,0.2,0.25,0.3)
#' @examples L=600
#' @examples toys=cortoymodel(cf,n,u,s,L)
cortoymodel<-function(cf,n,u,s,L){
  #This function generates a family of time series with a cluster structure.
  f1=chol(cf)

  m=length(n)
  #The symbol m is the number of clusters.


  f=t(t(f1)%*%matrix(data=rnorm(L*m,0,1),m,L))
  #These codes use Choleski decomposition to generate m factors.

  tm=matrix(data=0,nrow = m,ncol = 2)
  tm[1,]=c(1,n[1])
  for (i in 2:m){
    tm[i,]=c(sum(n[1:c(i-1)])+1,sum(n[1:i]))
  }
  #These lines of code are used to assign labels for different clusters.

  ns=sum(n)
  toys=matrix(data=0,nrow = L,ncol = ns)
  for (i in 1:m){
    toys[,tm[i,1]:tm[i,2]]=toymodelseries(f[,i],n[i],u[i,],s[i])
  }
  return(toys)
}
