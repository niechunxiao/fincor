#' This function calculates the kNN network from the distance matrix.
#'
#' @param cm Correlation matrix
#' @param k The parameter of the kNN network.
#'
#' @return The adjacency matrix of the network.
#' @export
#'
#' @examples adj3=ctoknnnetwork(cm,3)
ctoknnnetwork<-function(cm,k){
  #This function is used to compute the k-nearest neighbor network, where d is the distance matrix and k is the parameter.
  n=dim(cm)
  n1=n[1]
  adj=matrix(data=0,nrow=n1,ncol = n1)
  for (i in 1:n1){
    adj[i,]=corkneighbors(cm,i,k)
  }
  adj1=adj+t(adj)
  adj2=ifelse(adj1>0,1,0)
  for (i in 1:n1){
    adj2[i,i]=0
  }
  return(adj2)
}
