#' A function to find neighbors.
#'
#' @param d Distance matrix
#' @param i The label of the node.
#' @param k k neighbors.
#'
#' @return A collection of k neighbors.
#' @export
#'
#' @examples
kneighbors<-function(d,i,k){
  #This function detects the k neighbors of node i.
  di=d[i,]
  s1=unique(di)
  s2=sort(s1)
  k1=k+1
  sk=s2[k1]
  ci=ifelse(di<=sk,1,0)
  return(ci)
}
