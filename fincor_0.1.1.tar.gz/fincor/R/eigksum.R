#' A function that calculates the sum of the top k eigenvalues of a correlation matrix.
#'
#' @param coe correlation matrix
#' @param k k eigenvalues
#'
#' @return The sum of the top k eigenvalues of the correlation matrix.
#' @export
#'
#' @examples ek=eigksum(coe,3)
eigksum<-function(coe,k){
  e=eigen(coe)
  eval=e$values
  seval=sort(eval,decreasing = TRUE)
  ek=sum(seval[1:k])
  return(ek)
}
